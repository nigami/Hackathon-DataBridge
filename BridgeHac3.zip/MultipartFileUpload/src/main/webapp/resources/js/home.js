$("#imageSubmit").click(function(){
	console.log("I m inn");
})